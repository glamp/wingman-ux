const D="0123456789ABCDEFGHJKMNPQRSTVWXYZ";var h;(function(o){o.Base32IncorrectEncoding="B32_ENC_INVALID",o.DecodeTimeInvalidCharacter="DEC_TIME_CHAR",o.DecodeTimeValueMalformed="DEC_TIME_MALFORMED",o.EncodeTimeNegative="ENC_TIME_NEG",o.EncodeTimeSizeExceeded="ENC_TIME_SIZE_EXCEED",o.EncodeTimeValueMalformed="ENC_TIME_MALFORMED",o.PRNGDetectFailure="PRNG_DETECT",o.ULIDInvalid="ULID_INVALID",o.Unexpected="UNEXPECTED",o.UUIDInvalid="UUID_INVALID"})(h||(h={}));class w extends Error{constructor(t,e){super(`${e} (${t})`),this.name="ULIDError",this.code=t}}function I(o){const t=Math.floor(o()*32)%32;return D.charAt(t)}function _(o){const t=L(),e=t&&(t.crypto||t.msCrypto)||null;if(typeof(e==null?void 0:e.getRandomValues)=="function")return()=>{const n=new Uint8Array(1);return e.getRandomValues(n),n[0]/255};if(typeof(e==null?void 0:e.randomBytes)=="function")return()=>e.randomBytes(1).readUInt8()/255;throw new w(h.PRNGDetectFailure,"Failed to find a reliable PRNG")}function L(){return O()?self:typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:null}function B(o,t){let e="";for(;o>0;o--)e=I(t)+e;return e}function $(o,t=10){if(isNaN(o))throw new w(h.EncodeTimeValueMalformed,`Time must be a number: ${o}`);if(o>0xffffffffffff)throw new w(h.EncodeTimeSizeExceeded,`Cannot encode a time larger than ${0xffffffffffff}: ${o}`);if(o<0)throw new w(h.EncodeTimeNegative,`Time must be positive: ${o}`);if(Number.isInteger(o)===!1)throw new w(h.EncodeTimeValueMalformed,`Time must be an integer: ${o}`);let e,n="";for(let r=t;r>0;r--)e=o%32,n=D.charAt(e)+n,o=(o-e)/32;return n}function O(){return typeof WorkerGlobalScope<"u"&&self instanceof WorkerGlobalScope}function P(o,t){const e=_(),n=Date.now();return $(n,10)+B(16,e)}class G{constructor(){this.entries=[],this.errors=[],this.maxEntries=100,this.removeWingmanLogs=!0,this.wrapConsole(),this.setupErrorHandlers()}wrapConsole(){["log","info","warn","error"].forEach(e=>{const n=console[e];console[e]=(...r)=>{this.addEntry(e,r),n.apply(console,r)}})}setupErrorHandlers(){window.addEventListener("error",t=>{var e;this.addError({message:t.message,stack:(e=t.error)==null?void 0:e.stack,ts:Date.now()})}),window.addEventListener("unhandledrejection",t=>{var e;this.addError({message:`Unhandled Promise Rejection: ${t.reason}`,stack:(e=t.reason)==null?void 0:e.stack,ts:Date.now()})})}addEntry(t,e){this.removeWingmanLogs&&(e!=null&&e[0].startsWith("[Wingman"))||(this.entries.push({level:t,args:this.sanitizeArgs(e),ts:Date.now()}),this.entries.length>this.maxEntries&&this.entries.shift())}addError(t){this.errors.push(t),this.errors.length>this.maxEntries&&this.errors.shift()}sanitizeArgs(t){return t.map(e=>{try{return typeof e=="function"?"[Function]":typeof e=="object"&&e!==null?JSON.parse(JSON.stringify(e,(n,r)=>typeof r=="function"?"[Function]":typeof r>"u"?"[undefined]":r)):e}catch{return"[Unserializable]"}})}getEntries(){return this.entries}getErrors(){return this.errors}clear(){this.entries=[],this.errors=[]}}class F{constructor(){this.entries=[],this.maxEntries=50,this.observer=null,this.setupObserver()}setupObserver(){if(!window.PerformanceObserver){console.warn("PerformanceObserver not supported");return}try{this.observer=new PerformanceObserver(t=>{for(const e of t.getEntries())if(e.entryType==="resource"){const n=e;this.addEntry({url:n.name,startTime:n.startTime,duration:n.duration,initiatorType:n.initiatorType})}}),this.observer.observe({entryTypes:["resource"],buffered:!0})}catch(t){console.warn("Failed to setup PerformanceObserver:",t)}}addEntry(t){this.entries.push(t),this.entries.length>this.maxEntries&&this.entries.shift()}getEntries(){return this.entries}clear(){this.entries=[]}destroy(){this.observer&&(this.observer.disconnect(),this.observer=null)}}function z(o){const t=document.createElement("div");t.innerHTML=o;function e(r){var d;if(r.nodeType===Node.TEXT_NODE)return r.textContent||"";if(r.nodeType!==Node.ELEMENT_NODE)return"";const a=r,s=a.tagName.toLowerCase();let i=Array.from(a.childNodes).map(e).join("");switch(s){case"strong":case"b":return`**${i}**`;case"em":case"i":return`*${i}*`;case"code":return((d=a.parentElement)==null?void 0:d.tagName.toLowerCase())==="pre"?i:`\`${i}\``;case"pre":return`
\`\`\`
${i}
\`\`\`
`;case"a":const u=a.getAttribute("href")||"";return`[${i}](${u})`;case"ul":return`
`+Array.from(a.children).map(p=>`- ${Array.from(p.childNodes).map(e).join("")}`).join(`
`)+`
`;case"ol":return`
`+Array.from(a.children).map((p,m)=>{const y=Array.from(p.childNodes).map(e).join("");return`${m+1}. ${y}`}).join(`
`)+`
`;case"p":return i+`

`;case"br":return`
`;case"div":return i.trim()?i+`
`:i;default:return i}}return Array.from(t.childNodes).map(e).join("").trim().replace(/\n{3,}/g,`

`)}function q(o){const t=document.createElement("div");t.id="wingman-overlay",t.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2147483647;
    pointer-events: none;
  `;const e=document.createElement("div");e.id="wingman-highlighter",e.style.cssText=`
    position: fixed;
    border: 2px solid #0084ff;
    background: rgba(0, 132, 255, 0.1);
    pointer-events: none;
    transition: all 0.1s ease;
  `;const n=document.createElement("div");n.id="wingman-note-panel",n.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    pointer-events: all;
    display: none;
    z-index: 2147483648;
    width: 360px;
  `;const r=document.createElement("div");r.style.cssText=`
    display: flex;
    gap: 4px;
    margin-bottom: 8px;
    padding-bottom: 8px;
    border-bottom: 1px solid #e0e0e0;
    flex-wrap: wrap;
  `;const a=`
    padding: 4px 8px;
    border: 1px solid #e0e0e0;
    background: white;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `;[{text:"B",command:"bold",title:"Bold (Cmd/Ctrl+B)"},{text:"I",command:"italic",title:"Italic (Cmd/Ctrl+I)"},{text:"</>",command:"code",title:"Code (Cmd/Ctrl+`)"},{text:"•",command:"insertUnorderedList",title:"Bullet List"},{text:"1.",command:"insertOrderedList",title:"Numbered List"},{text:"🔗",command:"link",title:"Insert Link (Cmd/Ctrl+K)"},{text:"{ }",command:"codeblock",title:"Code Block"}].forEach(c=>{const l=document.createElement("button");l.textContent=c.text,l.title=c.title,l.style.cssText=a,c.command==="bold"?l.style.fontWeight="bold":c.command==="italic"&&(l.style.fontStyle="italic"),l.onmouseover=()=>{l.style.background="#f0f0f0",l.style.borderColor="#0084ff"},l.onmouseout=()=>{l.style.background="white",l.style.borderColor="#e0e0e0"},l.onmousedown=f=>{f.preventDefault(),u(c.command)},r.appendChild(l)});const i=document.createElement("div");i.contentEditable="true",i.setAttribute("data-placeholder","Describe the issue..."),i.style.cssText=`
    width: 100%;
    min-height: 100px;
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 8px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 14px;
    margin-bottom: 12px;
    outline: none;
    line-height: 1.5;
  `;const d=document.createElement("style");d.textContent=`
    #wingman-note-panel div[contenteditable]:empty:before {
      content: attr(data-placeholder);
      color: #999;
      pointer-events: none;
      display: block;
    }
    #wingman-note-panel div[contenteditable] code {
      background: #f4f4f4;
      padding: 2px 4px;
      border-radius: 3px;
      font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
      font-size: 0.9em;
    }
    #wingman-note-panel div[contenteditable] pre {
      background: #f4f4f4;
      padding: 8px;
      border-radius: 4px;
      margin: 8px 0;
      overflow-x: auto;
    }
    #wingman-note-panel div[contenteditable] pre code {
      background: none;
      padding: 0;
    }
    #wingman-note-panel div[contenteditable] a {
      color: #0084ff;
      text-decoration: underline;
    }
    #wingman-note-panel div[contenteditable]:focus {
      border-color: #0084ff;
      box-shadow: 0 0 0 2px rgba(0, 132, 255, 0.1);
    }
  `,document.head.appendChild(d);function u(c){if(i.focus(),c==="link"){const l=prompt("Enter URL:");if(l){const f=window.getSelection();f&&f.toString()?document.execCommand("createLink",!1,l):document.execCommand("insertHTML",!1,`<a href="${l}">${l}</a>`)}}else if(c==="code"){const l=window.getSelection();l&&l.toString()&&document.execCommand("insertHTML",!1,`<code>${l.toString()}</code>`)}else if(c==="codeblock"){const l=window.getSelection(),f=l?l.toString():"";document.execCommand("insertHTML",!1,`<pre><code>${f||"// Code here"}</code></pre><p></p>`)}else document.execCommand(c,!1)}i.addEventListener("keydown",c=>{if(navigator.platform.toUpperCase().indexOf("MAC")>=0?c.metaKey:c.ctrlKey)switch(c.key.toLowerCase()){case"b":c.preventDefault(),u("bold");break;case"i":c.preventDefault(),u("italic");break;case"`":c.preventDefault(),u("code");break;case"k":c.preventDefault(),u("link");break}});const p=document.createElement("div");p.style.cssText=`
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  `;const m=document.createElement("button");m.textContent="Cancel",m.style.cssText=`
    padding: 6px 16px;
    border: 1px solid #e0e0e0;
    background: white;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
  `;const y=document.createElement("button");y.textContent="Send",y.style.cssText=`
    padding: 6px 16px;
    border: none;
    background: #0084ff;
    color: white;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
  `,p.appendChild(m),p.appendChild(y),n.appendChild(r),n.appendChild(i),n.appendChild(p),t.appendChild(e),t.appendChild(n),document.body.appendChild(t);let x=null,b=null,W="element";t.style.pointerEvents="all";const C=c=>{{const f=document.elementsFromPoint(c.clientX,c.clientY).find(g=>g!==t&&g!==e&&g!==n&&!t.contains(g)&&!n.contains(g));if(f){const g=f.getBoundingClientRect();e.style.left=`${g.left}px`,e.style.top=`${g.top}px`,e.style.width=`${g.width}px`,e.style.height=`${g.height}px`,e.style.display="block"}else e.style.display="none"}},M=c=>{c.preventDefault(),c.stopPropagation();const f=document.elementsFromPoint(c.clientX,c.clientY).find(g=>g!==t&&g!==e&&g!==n&&!t.contains(g)&&!n.contains(g));f&&(x=f,b=f.getBoundingClientRect(),n.style.display="block",i.focus(),t.removeEventListener("mousemove",C),t.style.pointerEvents="none",n.style.pointerEvents="all")};t.addEventListener("mousemove",C),t.addEventListener("click",M),m.addEventListener("click",()=>{v(),o.onCancel()}),y.addEventListener("click",()=>{const c=i.innerHTML.trim();if(!c||c==="<br>"){i.focus();return}const l=z(c),f={mode:W,rect:b?{x:b.left,y:b.top,width:b.width,height:b.height}:null,selector:x?K(x):void 0};v(),o.onSubmit(l,f,x||void 0)});const k=c=>{c.key==="Escape"&&(v(),o.onCancel())};document.addEventListener("keydown",k);function v(){t.remove(),document.removeEventListener("keydown",k)}return{cleanup:v}}function K(o){var n;const t=[];let e=o;for(;e&&e!==document.body;){let r=e.tagName.toLowerCase();if(e.id){r=`#${e.id}`,t.unshift(r);break}if(e.className){const s=Array.from(e.classList).filter(i=>!i.startsWith("wingman-")).join(".");s&&(r+=`.${s}`)}const a=Array.from(((n=e.parentNode)==null?void 0:n.children)||[]);if(a.length>1){const s=a.indexOf(e)+1;r+=`:nth-child(${s})`}t.unshift(r),e=e.parentElement}return t.join(" > ")}function T(o){const t=[];let e=o;for(;e&&e!==document.body&&e.parentElement;){let r=e.tagName.toLowerCase();if(e.id&&!e.id.includes(":")){t.unshift(`#${CSS.escape(e.id)}`);break}const a=Array.from(e.attributes).filter(i=>i.name.startsWith("data-")&&!i.name.includes("react")&&!i.name.includes("wingman")).map(i=>`[${i.name}="${CSS.escape(i.value)}"]`).slice(0,2);if(a.length>0)r+=a.join("");else if(e.className){const i=Array.from(e.classList).filter(d=>!d.startsWith("css-")&&!d.match(/^[a-z]{2,3}-[0-9]+/)&&d.length<30).slice(0,2).map(d=>`.${CSS.escape(d)}`);i.length>0&&(r+=i.join(""))}const s=e.parentElement;if(s){const d=Array.from(s.children).filter(u=>u.tagName===e.tagName);if(d.length>1){const u=d.indexOf(e)+1;r+=`:nth-of-type(${u})`}}t.unshift(r),e=e.parentElement}let n=t.join(" > ");try{const r=document.querySelectorAll(n);return r.length===1&&r[0]===o?(console.log("[Wingman Selector] Generated unique selector:",n),n):r.length===0?(console.warn("[Wingman Selector] Selector matches no elements, using fallback"),N(o)):(console.warn("[Wingman Selector] Selector matches multiple elements, using fallback"),N(o))}catch(r){return console.error("[Wingman Selector] Invalid selector generated:",r),N(o)}}function N(o){const t=[];let e=o;for(;e&&e!==document.body&&e.parentElement;){const r=e.parentElement,s=Array.from(r.children).indexOf(e)+1;let i=e.tagName.toLowerCase();i+=`:nth-child(${s})`,t.unshift(i),e=e.parentElement}const n="body > "+t.join(" > ");console.log("[Wingman Selector] Using fallback selector:",n);try{const r=document.querySelectorAll(n);if(r.length===1&&r[0]===o)return n}catch(r){console.error("[Wingman Selector] Fallback selector also failed:",r)}return U(o)}function U(o){const t=document.querySelectorAll("*"),e=Array.from(t).indexOf(o);return e===-1?(console.error("[Wingman Selector] Element not found in document!"),"wingman-element-not-found"):(`${o.tagName.toLowerCase()}${Math.floor(e/10)}`,console.warn("[Wingman Selector] Using last resort selector with document index:",e),o.setAttribute("data-wingman-temp-index",e.toString()),`[data-wingman-temp-index="${e}"]`)}function S(){document.querySelectorAll("[data-wingman-temp-index]").forEach(t=>{t.removeAttribute("data-wingman-temp-index")})}class j{constructor(t={}){this.sdkReady=!1,this.requestCounter=0,this.pendingRequests=new Map,this.debug=t.debug||!1,this.timeout=t.timeout||3e3,this.initialize()}initialize(){window.addEventListener("message",this.handleMessage.bind(this)),this.checkSDKReady()}handleMessage(t){if(t.source!==window)return;const{type:e,requestId:n,data:r,selector:a}=t.data||{};switch(e){case"WINGMAN_SDK_READY":this.sdkReady=!0,this.debug&&console.log("[Wingman Bridge] SDK is ready");break;case"WINGMAN_REACT_DATA_RESPONSE":this.handleResponse(n,r);break;case"WINGMAN_SELECTOR_RESPONSE":this.handleResponse(n,a);break}}handleResponse(t,e){const n=this.pendingRequests.get(t);n&&(clearTimeout(n.timeoutId),n.resolve(e),this.pendingRequests.delete(t))}checkSDKReady(){let t=0;const e=5,n=()=>{if(this.sdkReady||t>=e){!this.sdkReady&&this.debug&&console.log("[Wingman Bridge] SDK not detected after",t,"attempts");return}t++,console.log("[Wingman Bridge] Sending PING to check SDK (attempt",t,")"),window.postMessage({type:"WINGMAN_PING"},"*"),setTimeout(n,Math.min(100*Math.pow(2,t),2e3))};n()}generateRequestId(){return`req_${Date.now()}_${++this.requestCounter}`}sendRequest(t,e){return new Promise((n,r)=>{const a=this.generateRequestId(),s=setTimeout(()=>{this.pendingRequests.delete(a),r(new Error(`SDK request timeout after ${this.timeout}ms`))},this.timeout);this.pendingRequests.set(a,{resolve:n,reject:r,timeoutId:s}),window.postMessage({type:t,requestId:a,...e},"*"),this.debug&&console.log(`[Wingman Bridge] Sent request: ${t}`,e)})}isSDKReady(){return this.sdkReady}async getReactData(t){if(console.log("[Wingman Bridge] Getting React data for element:",t),this.sdkReady||(console.log("[Wingman Bridge] SDK not ready, waiting 500ms..."),await new Promise(e=>setTimeout(e,500))),!this.sdkReady){this.debug&&console.log("[Wingman Bridge] SDK still not ready after wait, attempting direct extraction");const e=this.extractReactDataDirectly(t);return console.log("[Wingman Bridge] Direct extraction result:",e),e}try{const e=T(t);console.log("[Wingman Bridge] Generated selector for element:",e),console.log("[Wingman Bridge] Sending request to SDK for React data");const n=await this.sendRequest("WINGMAN_GET_REACT_DATA",{selector:e});return S(),this.debug&&console.log("[Wingman Bridge] Received React data from SDK:",n),n||{obtainedVia:"none"}}catch(e){this.debug&&console.warn("[Wingman Bridge] Failed to get React data from SDK:",e);const n=this.extractReactDataDirectly(t);return console.log("[Wingman Bridge] Fallback direct extraction result:",n),S(),n}}async getRobustSelector(t){try{const e=T(t);return this.debug&&console.log("[Wingman Bridge] Generated robust selector:",e),S(),e}catch(e){return this.debug&&console.warn("[Wingman Bridge] Failed to generate selector:",e),this.generateBasicSelector(t)}}extractReactDataDirectly(t){var e;try{const n=Object.keys(t);console.log("[Wingman Bridge] Element keys:",n.filter(m=>m.includes("react")||m.includes("React")));const r=n.find(m=>m.startsWith("__reactInternalInstance")||m.startsWith("__reactFiber")||m.startsWith("_reactInternal")||/^__reactFiber\$/.test(m)||/^__reactProps\$/.test(m));if(!r)return console.log("[Wingman Bridge] No React fiber key found on element"),{obtainedVia:"none"};console.log("[Wingman Bridge] Found React fiber key:",r);const a=t[r];if(!a)return{obtainedVia:"none"};let s=a;for(;s&&typeof s.type=="string";)s=s.return;if(!s)return{obtainedVia:"none"};const i={obtainedVia:"fiber-direct"};s.type&&typeof s.type=="function"&&(i.componentName=s.type.displayName||s.type.name||"Unknown",(e=s.type.prototype)!=null&&e.isReactComponent?i.componentType="class":i.componentType="function"),s.memoizedProps&&(i.props=this.sanitizeBasic(s.memoizedProps)),s.memoizedState&&i.componentType==="class"&&(i.state=this.sanitizeBasic(s.memoizedState));const d=[];let u=s.return,p=0;for(;u&&p<5;){if(u.type&&typeof u.type!="string"){const m=u.type.displayName||u.type.name;m&&d.push(m)}u=u.return,p++}return d.length>0&&(i.parentComponents=d),i}catch(n){return this.debug&&console.warn("[Wingman Bridge] Direct React extraction failed:",n),{obtainedVia:"none"}}}sanitizeBasic(t,e=0,n=2){if(e>n)return"[Max depth]";if(t==null)return t;if(typeof t=="function")return"[Function]";if(typeof t=="symbol")return t.toString();if(typeof t=="string")return t.length>100?t.substring(0,100)+"...":t;if(Array.isArray(t))return t.slice(0,5).map(r=>this.sanitizeBasic(r,e+1,n));if(typeof t=="object"){const r={},a=Object.keys(t).slice(0,10);for(const s of a)if(!(s.startsWith("_")||s.startsWith("$$")))try{r[s]=this.sanitizeBasic(t[s],e+1,n)}catch{r[s]="[Unserializable]"}return r}return t}generateBasicSelector(t){var r;const e=[];let n=t;for(;n&&n!==document.body;){let a=n.tagName.toLowerCase();if(n.id){a=`#${n.id}`,e.unshift(a);break}if(n.className){const i=Array.from(n.classList).filter(d=>!d.startsWith("wingman-")).join(".");i&&(a+=`.${i}`)}const s=Array.from(((r=n.parentNode)==null?void 0:r.children)||[]);if(s.length>1){const i=s.indexOf(n)+1;a+=`:nth-child(${i})`}e.unshift(a),n=n.parentElement}return e.join(" > ")}destroy(){for(const[t,e]of this.pendingRequests)clearTimeout(e.timeoutId),e.reject(new Error("SDK Bridge destroyed"));this.pendingRequests.clear(),window.removeEventListener("message",this.handleMessage.bind(this))}}console.log("[Wingman] Content script loaded on:",window.location.href);const R=new G,V=new F,A=new j({debug:!0});let E=!1;chrome.runtime.onMessage.addListener((o,t,e)=>{if(console.log("[Wingman] Message received:",o),o.type==="ACTIVATE_OVERLAY")return E?(console.log("[Wingman] Overlay already active"),e({success:!1,reason:"already_active"})):(console.log("[Wingman] Activating overlay..."),H(),e({success:!0})),!0});function H(){try{E=!0,console.log("[Wingman] Creating overlay UI...");const o=q({onSubmit:async(t,e,n)=>{try{const r=await X();let a;if(n){console.log("[Wingman] Extracting React data for element..."),a=await A.getReactData(n);const u=await A.getRobustSelector(n);u&&(e.selector=u)}const s=J(t,e,r,a),i={...s,media:{...s.media,screenshot:{...s.media.screenshot,dataUrl:s.media.screenshot.dataUrl.substring(0,100)+"...[truncated]"}}};console.log("[Wingman] Sending annotation payload:",i);const d=await Y(s);console.log("[Wingman] Annotation submitted successfully:",d),E=!1}catch(r){console.error("[Wingman] Failed to submit feedback:",r),E=!1}},onCancel:()=>{console.log("[Wingman] Overlay cancelled"),E=!1}});console.log("[Wingman] Overlay created successfully")}catch(o){console.error("[Wingman] Failed to create overlay:",o),E=!1}}async function X(){return new Promise((o,t)=>{chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOT"},e=>{chrome.runtime.lastError?t(chrome.runtime.lastError):o(e)})})}async function Y(o){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"SUBMIT_ANNOTATION",payload:o},n=>{chrome.runtime.lastError?e(chrome.runtime.lastError):t(n)})})}function J(o,t,e,n){return{id:Z(),createdAt:new Date().toISOString(),note:o,page:{url:window.location.href,title:document.title,ua:navigator.userAgent,viewport:{w:window.innerWidth,h:window.innerHeight,dpr:window.devicePixelRatio||1}},target:t,media:{screenshot:{mime:"image/png",dataUrl:e}},console:R.getEntries(),errors:R.getErrors(),network:V.getEntries(),react:n}}function Z(){return P()}
